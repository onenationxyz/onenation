Logo // ONE NATION
==================

 > Welcome home ! One Nation is headless so you are free to collaborate/append/modifiy/fork anything without asking permission. [Read our Contribution Guide](./contribution_guide.md)

## EN

> This section needs a lot more precisions. Coming soon...

The original working document is made with Affinity Designer [logo_onenation.afdesign](./logo_onenation.afdesign)

## FR

> Cette section doit être complétée très prochainement

Le fichier de travail est un fichier Affinity Designer [logo_onenation.afdesign](./logo_onenation.afdesign)